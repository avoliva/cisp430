/*
 * @name Adam Voliva
 * @desc Assign 2 List, Stack and Queue
 * @date March 11th, 2013
 * @class CISP430
 */

#ifndef CONF_H
#define CONF_H
# ifdef __DEFAULT_TEMPLATES
#   define __DEFAULT_TMPL(_Tp)
# else
#   define __DEFAULT_TMPL(_Tp) = _Tp
# endif
#endif
